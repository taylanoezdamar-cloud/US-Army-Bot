U.S.Army Discord Bot

1. .env.example in .env umbenennen.
2. Deinen Discord Bot Token in .env eintragen.
3. Im Ordner `npm install` ausführen.
4. Danach `node index.js` oder start.bat starten.

Befehle:
/ping
/personal einstellen
/personal entlassen
/personal uprank

Dienstnummern:
Rang 21 = 01/02
Rang 20 = 03/04
Rang 19 = 05/06
Rang 18-1 = zufällige freie DN 07-99

Uprank:
Auf 21 wird nur 01/02 vergeben.
Auf 20 wird nur 03/04 vergeben.
Auf 19 wird nur 05/06 vergeben.
Sind beide Nummern eines Zielrangs voll, wird der Uprank komplett abgebrochen.

Benötigte Rollen:
U.S.Army
General
Field Grade Officer
Hauptleute
Leutnant
Unteroffiziere
Mannschaft
Abteilungen
Bürger
sowie alle 21 Rangrollen aus index.js.

Die Bot-Rolle muss über den Rollen liegen, die der Bot vergeben/entfernen soll.
