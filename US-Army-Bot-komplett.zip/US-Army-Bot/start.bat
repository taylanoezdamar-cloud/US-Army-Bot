@echo off
title U.S.Army Bot
node index.js
pause
